{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE OverloadedStrings #-}

module Lib
    ( searchEngineModule
    ) where

import PageData ( PageData )
import Parser ( parser, linkHtmlParser, something, linkParser )
import Loader ( getHtml, loadData, getUrl )
import Graph ( createGraph )

searchEngine :: IO [Maybe PageData] -> IO ()
searchEngine pages = do
  unpackedPages <- pages :: IO[Maybe PageData]

  let currentLinks = linkParser $ map getUrl unpackedPages
  let words = map(parser . getHtml) unpackedPages
  let otherLinks = map(linkHtmlParser . getHtml) unpackedPages

  print $ createGraph currentLinks otherLinks


searchEngineModule :: IO ()
searchEngineModule = do
    let decoded = loadData "data/data.json"
    searchEngine decoded

