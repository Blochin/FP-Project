{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE OverloadedStrings #-}
module Lib
    ( loader
    ) where
import Data.Text ( Text,unpack)
import qualified Data.Text as T
import Data.ByteString ()
import qualified Data.ByteString.Lazy
import Control.Applicative (Alternative (empty))
import Data.ByteString.Internal (c2w)
import Data.ByteString.Lazy (ByteString, readFile, split)
import Data.Maybe (isJust)
import Data.Aeson
  ( FromJSON (parseJSON),
    Value (Object),
    decode,
    (.:), eitherDecode,
  )
import Parser(something)

--https://www.schoolofhaskell.com/school/starting-with-haskell/libraries-and-frameworks/text-manipulation/json
data PageData =
  PageData { url  :: !Text
          , html_content   :: !Text
           } deriving (Show)

instance FromJSON PageData where
  parseJSON (Object v) = do
    url <- v .: "url"
    html_content <- v .: "html_content"
    return (PageData {url = url, html_content = html_content})
  parseJSON _ = Control.Applicative.empty

loadFile :: FilePath -> IO ByteString
loadFile = Data.ByteString.Lazy.readFile

loadParsedData :: FilePath -> IO [Maybe PageData]
loadParsedData file = do
  res <- loadFile file
  let byLine = split (c2w '\n') res :: [ByteString]
  let decoded = map (\line -> decode line :: Maybe PageData) byLine
  return decoded

showUrl :: Maybe PageData -> String
showUrl (Just pageData) = unpack $ url pageData
showUrl Nothing = undefined

showhtml :: Maybe PageData -> String
showhtml (Just pageData) = unpack $ html_content pageData
showhtml Nothing = undefined

printUrl :: IO [Maybe PageData] -> IO ()
printUrl packedobject = do
  unpackedobject <- packedobject :: IO[Maybe PageData]
  mapM_ (\s -> (print $ showhtml s)) unpackedobject


loader :: IO ()
loader = do
    let decoded = loadParsedData "data/data.json"
    -- printUrl decoded
    something
    return()