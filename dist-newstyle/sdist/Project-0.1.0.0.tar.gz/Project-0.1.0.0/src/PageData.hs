{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE OverloadedStrings #-}
module PageData
    ( something
    ) where
import Text.HTML.TagSoup
something :: IO ()
something = print "something"