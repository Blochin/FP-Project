{-# LANGUAGE FlexibleContexts #-}
{-# OPTIONS_GHC -Wno-incomplete-patterns #-}

module Graph
    ( createGraph
    ) where

import Data.Map ( insert )
import Data.Char ()
import Data.List ( nubBy )
import Parser ( linkHtmlParser, linkParser )
import Loader (getUrl, getHtml)
import PageData ( PageData )
import Data.Tuple.Select

printTouples :: (Show a, Show b) => (a, b) -> [Char]
printTouples (index, uid) = "index: " ++ show index ++ " page: " ++ show uid

--Not used but looks cool
rmDup :: (Eq a) => [(a, b)] -> [(a, b)]
rmDup lst = go lst []
    where go [] seen = seen
          go (x:xs) seen
              | any (\(a, _) -> a == fst x) seen = go xs seen
              | otherwise = go xs (seen ++ [x])

createIndexPageTouple :: Eq a => [a] -> [(a, Int)]
createIndexPageTouple links = do
    let indexes = [0.. length links-1]
    nubBy (\(x,_) (x', _) -> x == x') $ zip  links indexes

createGraph :: (Eq a1, Eq a2) => [a1] -> [[a2]] -> [[(a2, Int)]]
createGraph currentLinks otherLinks = do
    createIndexPageTouple currentLinks
    map (sel2 . createIndexPageTouple) otherLinks
    --TODO 



 